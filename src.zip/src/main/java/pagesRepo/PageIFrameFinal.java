package pagesRepo;

import org.openqa.selenium.WebDriver;

public class PageIFrameFinal extends PageUtility {
	
	public WebDriver driver;
	
	public PageIFrameFinal (WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	//Page Elements
	


}
